package psu.edu.CMPSC221;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cmpsc221Application {
	public static void main(String[] args) {
		SpringApplication.run(Cmpsc221Application.class, args);
	}
}