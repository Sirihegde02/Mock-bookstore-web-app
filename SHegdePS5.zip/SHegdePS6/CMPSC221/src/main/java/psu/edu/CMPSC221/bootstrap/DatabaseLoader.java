package psu.edu.CMPSC221.bootstrap;

import psu.edu.CMPSC221.repository.BookRepository;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import static psu.edu.CMPSC221.model.Genre.CLASSIC;
import static psu.edu.CMPSC221.model.Genre.HORROR;
import static psu.edu.CMPSC221.model.Genre.ROMANCE;
import static psu.edu.CMPSC221.model.Genre.NON_FICTION;

@Component
public class DatabaseLoader implements ApplicationListener<ContextRefreshedEvent> {
    private final BookRepository bookRepository;

    public DatabaseLoader(BookRepository bookRepository){
        this.bookRepository = bookRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event){
        System.out.println("It works");
        bookRepository.addBook(1, "Little Women", "Judith Rossner", 1234, "12/12/2022", NON_FICTION, 29.99);
        bookRepository.addBook(2, "The Shinning", "Stephen King", 2345, "12/13/2022", HORROR,39.99);
        bookRepository.addBook(3, "Three men in a boat", "Jerome K. Jerome", 3456, "12/14/2022",CLASSIC, 19.99);
        bookRepository.addBook(4, "Romeo and Juliet", " William Shakespeare ", 4567, "12/15/2022",ROMANCE, 59.99);
    }
}