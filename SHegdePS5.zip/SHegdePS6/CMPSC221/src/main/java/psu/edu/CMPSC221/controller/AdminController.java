package psu.edu.CMPSC221.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import psu.edu.CMPSC221.model.Book;
import psu.edu.CMPSC221.model.Genre;
import psu.edu.CMPSC221.service.BookService;

import java.util.List;

@Controller
public class AdminController {

    private final BookService bookService;

    public AdminController(BookService bookService) {
        this.bookService = bookService;
    }
    @GetMapping("/admin/books/view")
    public String admin(Model model) {
        List<Book> bookList = bookService.getBooks();
        model.addAttribute("bookList", bookList);
        return "admin";
    }

    @GetMapping("/delete/{bookId}")
    public String deleteBook(Model model, @PathVariable long bookId){
        bookService.deleteBook(bookId);
        List<Book> bookList = bookService.getBooks();
        model.addAttribute("bookList", bookList);
        return "admin";
    }

    @GetMapping("/admin/books/addBook")
    public String addBookGet(Model model){
        return "addBook";
    }

    @PostMapping("/addBook")
    public String addBookPost(Model model, @RequestParam String bookId, @RequestParam String bookName, @RequestParam String bookAuthor, @RequestParam String ISBN, @RequestParam String datePublished, @RequestParam String genre, @RequestParam double bookPrice){
        //  validate
        String errors = bookService.validateFormSubmit(bookName, bookAuthor, Long.parseLong(ISBN), datePublished, Genre.valueOf(genre.toUpperCase()), bookPrice);
        if (errors != null) {
            //
            //  bad case!
            model.addAttribute("error", errors);
            model.addAttribute("bookName", bookName);
            model.addAttribute("bookAuthor", bookAuthor);
            model.addAttribute("ISBN", ISBN);
            model.addAttribute("datePublished", datePublished);
            model.addAttribute("genre", genre);
            model.addAttribute("bookPrice", bookPrice);
        } else {
            //
            //  good case!
            model.addAttribute("success", "Changes were saved");
            bookService.addBook(Long.parseLong(bookId), bookName, bookAuthor, Long.parseLong(ISBN), datePublished, Genre.valueOf(genre.toUpperCase()), bookPrice);
        }
        List<Book> bookList = bookService.getBooks();
        model.addAttribute("bookList", bookList);
        return "admin";
    }

    @GetMapping("/edit/{bookId}")
    public String editBookGet(Model model, @PathVariable long bookId) {
        //
        //  get game details
        Book book = bookService.getBookById(bookId);

        //
        //  reload data
        model.addAttribute("bookName", book.getTitle());
        model.addAttribute("bookAuthor", book.getBookAuthor());
        model.addAttribute("bookPrice", book.getBookPrice());
        model.addAttribute("ISBN", book.getISBN());
        model.addAttribute("datePublished", book.getDatePublished());
        model.addAttribute("genre", book.getGenre());
        model.addAttribute("bookId", book.getBookId());
        return "editBook";
    }

    @PostMapping("/editBook")
    public String editBookPost(Model model, @RequestParam String bookId, @RequestParam String bookName, @RequestParam String bookAuthor, @RequestParam String ISBN, @RequestParam String datePublished, @RequestParam String genre, @RequestParam String bookPrice){
        //  validate
        String errors = bookService.validateFormSubmit(bookName, bookAuthor, Long.parseLong(ISBN), datePublished, Genre.valueOf(genre.toUpperCase()), Double.parseDouble(bookPrice));
        if (errors != null) {
            //
            //  bad case!
            model.addAttribute("error", errors);
            model.addAttribute("bookName", bookName);
            model.addAttribute("bookAuthor", bookAuthor);
            model.addAttribute("ISBN", ISBN);
            model.addAttribute("datePublished", datePublished);
            model.addAttribute("genre", genre);
            model.addAttribute("bookPrice", bookPrice);
        } else {
            //
            //  good case!
            model.addAttribute("success", "Changes were saved");
            bookService.editBook(Long.parseLong(bookId), bookName, bookAuthor, Long.parseLong(ISBN), datePublished, Genre.valueOf(genre.toUpperCase()), Double.parseDouble(bookPrice));
        }
        List<Book> bookList = bookService.getBooks();
        model.addAttribute("bookList", bookList);
        return "admin";
    }
}
