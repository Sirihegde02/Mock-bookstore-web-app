package psu.edu.CMPSC221.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import psu.edu.CMPSC221.model.Book;
import psu.edu.CMPSC221.model.Genre;
import psu.edu.CMPSC221.service.BookService;

import java.util.List;
import java.util.Locale;

@Controller
public class IndexController {

    private final BookService bookService;

    public IndexController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/")
    public String home(Model model) {
        List<Book> bookList = bookService.getBooks();
        model.addAttribute("bookList", bookList);
        return "home";
    }

    @PostMapping("/")
    public String addBookSubmit(Model model, @RequestParam long bookId, @RequestParam String bookName, @RequestParam String bookAuthor, @RequestParam long ISBN, @RequestParam String datePublished, @RequestParam Genre genre, @RequestParam double bookPrice) {

        //  validate
        String errors = bookService.validateFormSubmit(bookName, bookAuthor, ISBN, datePublished, genre, bookPrice);
        if (errors != null) {
            //
            //  bad case!
            model.addAttribute("error", errors);
            model.addAttribute("bookName", bookName);
            model.addAttribute("bookAuthor", bookAuthor);
            model.addAttribute("ISBN", ISBN);
            model.addAttribute("datePublished", datePublished);
            model.addAttribute("genre", genre);
            model.addAttribute("bookPrice", bookPrice);
        } else {
            //
            //  good case!
            model.addAttribute("success", "Changes were saved");
            bookService.addBook(bookId, bookName, bookAuthor, ISBN, datePublished, genre, bookPrice);
        }

        //
        //  reload the games
        List<Book> bookList = bookService.getBooks();
        model.addAttribute("bookList", bookList);
        return "home";
    }

    @GetMapping("/contact-us")
    public String contact(Model model) {
        return "contact-us";
    }

    @PostMapping("/contact-email")
    public String sendMessage(Model model, @RequestParam String name, @RequestParam String email, @RequestParam String subject, @RequestParam String message) {
        return "redirect:/";
    }

    @GetMapping( "/search")
    public String searchByTitle(Model model, @RequestParam String search) {
        List<Book> bookList = bookService.getBooks();
        var filtered = bookList.stream().filter(g -> g.getTitle().toLowerCase().contains(search.toLowerCase(Locale.ROOT)) || g.getBookAuthor().toLowerCase().contains(search.toLowerCase(Locale.ROOT))).toList();
        model.addAttribute("bookList", filtered);
        return "home";
    }

}