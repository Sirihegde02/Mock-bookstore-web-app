package psu.edu.CMPSC221.model;

public class Book {
    private Long bookId;

    private String title;

    private String bookAuthor;

    private Long ISBN;

    private String datePublished;

    private Genre genre;

    private Double bookPrice;

    public Book(Long bookId, String Title, String bookAuthor, Long ISBN, String datePublished, Genre genre, Double bookPrice) {
        this.bookId = bookId;
        this.title = Title;
        this.datePublished = datePublished;
        this.ISBN = ISBN;
        this.genre = genre;
        this.bookAuthor = bookAuthor;
        this.bookPrice = bookPrice;
    }

    public Long getBookId() {
        return bookId;
    }

    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public Double getBookPrice() {
        return bookPrice;
    }

    public void setBookPrice(Double bookPrice) {
        this.bookPrice = bookPrice;
    }

    public Long getISBN() {
        return ISBN;
    }

    public String getDatePublished() {
        return datePublished;
    }

    public Genre getGenre() {
        return genre;
    }

    public void setISBN(Long ISBN) {
        this.ISBN = ISBN;
    }

    public void setDatePublished(String datePublished) {
        this.datePublished = datePublished;
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
    }

}