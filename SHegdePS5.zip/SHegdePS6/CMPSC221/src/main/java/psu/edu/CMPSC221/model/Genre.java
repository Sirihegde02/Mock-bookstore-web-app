package psu.edu.CMPSC221.model;

public enum Genre {
    HORROR, NON_FICTION, ROMANCE, CLASSIC;
}