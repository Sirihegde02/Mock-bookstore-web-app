package psu.edu.CMPSC221.repository;

import psu.edu.CMPSC221.model.Book;
import psu.edu.CMPSC221.model.Genre;

import java.util.List;

public interface BookRepository {
    List<Book> getBooks();

    void addBook(long bookId, String bookName, String bookAuthor, long ISBN, String datePublished, Genre genre, double bookPrice);

    void deleteBook(long bookId);

    Book getBookById(long bookId);
}
