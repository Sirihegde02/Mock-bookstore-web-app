package psu.edu.CMPSC221.repository.impl;

import com.google.common.collect.MoreCollectors;
import org.springframework.stereotype.Repository;
import psu.edu.CMPSC221.model.Book;
import psu.edu.CMPSC221.model.Genre;
import psu.edu.CMPSC221.repository.BookRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Repository
public class BookRepositoryImpl implements BookRepository {
    private List<Book> bookList;

    public BookRepositoryImpl() {
        this.bookList = new ArrayList<>();
    }

    @Override
    public List<Book> getBooks() {
        return bookList;
    }

    @Override
    public void addBook(long bookId, String bookName, String bookAuthor, long ISBN, String datePublished, Genre genre, double bookPrice) {
        bookList.add(new Book(bookId, bookName, bookAuthor, ISBN, datePublished, genre, bookPrice));
    }

    @Override
    public void deleteBook(long bookId) {
        bookList = bookList.stream().filter(g -> !Objects.equals(g.getBookId(), bookId)).collect(Collectors.toList());
    }

    @Override
    public Book getBookById(long bookId) {
        return bookList.stream().filter(g -> Objects.equals(g.getBookId(), bookId)).collect(MoreCollectors.onlyElement());
    }
}
