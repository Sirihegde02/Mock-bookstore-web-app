package psu.edu.CMPSC221.service;

import psu.edu.CMPSC221.model.Book;
import psu.edu.CMPSC221.model.Genre;

import java.util.List;
public interface BookService {
    List<Book> getBooks();

    String validateFormSubmit(String bookName, String bookAuthor, long ISBN, String datePublished, Genre genre, double bookPrice);

    void addBook(long bookId, String bookName, String bookAuthor, long ISBN, String datePublished, Genre genre, double bookPrice);

    void deleteBook(long bookId);

    Book getBookById(long bookId);

    void editBook(long bookId, String bookName, String bookAuthor, long ISBN, String datePublished, Genre genre, double bookPrice);
}
