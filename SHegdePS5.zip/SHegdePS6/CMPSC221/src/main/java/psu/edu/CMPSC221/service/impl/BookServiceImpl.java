package psu.edu.CMPSC221.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import psu.edu.CMPSC221.model.Book;
import psu.edu.CMPSC221.model.Genre;
import psu.edu.CMPSC221.repository.BookRepository;
import psu.edu.CMPSC221.service.BookService;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    private final BookRepository bookRepository;

    public BookServiceImpl(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public List<Book> getBooks() {
        return bookRepository.getBooks();
    }

    @Override
    public String validateFormSubmit(String bookName, String bookAuthor, long ISBN, String datePublished, Genre genre, double bookPrice) {
        if (!StringUtils.hasText(bookName)) {
            return "book name is required";
        }
        if (!StringUtils.hasText(bookAuthor)) {
            return "book author is required";
        }
        if (!StringUtils.hasText(String.valueOf(ISBN))) {
            return "book author is required";
        }
        if (!StringUtils.hasText(datePublished)) {
            return "book author is required";
        }
        if (!StringUtils.hasText(String.valueOf(genre))) {
            return "book author is required";
        }
        if (!StringUtils.hasText(String.valueOf(bookPrice))) {
            return "book price is required";
        }

        return null;
    }

    @Override
    public void addBook(long bookId, String bookName, String bookAuthor, long ISBN, String datePublished, Genre genre, double bookPrice) {
        bookRepository.addBook(10L, bookName, bookAuthor, ISBN, datePublished, genre, bookPrice);
    }

    @Override
    public void deleteBook(long bookId) {
        bookRepository.deleteBook(bookId);
    }

    @Override
    public Book getBookById(long bookId) {
        return bookRepository.getBookById(bookId);
    }

    @Override
    public void editBook(long bookId, String bookName, String bookAuthor, long ISBN, String datePublished, Genre genre, double bookPrice) {
        var book = bookRepository.getBookById(bookId);
        if (book != null) {
            book.setTitle(bookName);
            book.setBookAuthor(bookAuthor);
            book.setISBN(ISBN);
            book.setDatePublished(datePublished);
            book.setGenre(genre);
            book.setBookPrice(bookPrice);
        }
    }
}