package psu.edu.CMPSC221;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cmpsc221ApplicationTests {

	@Test
	void contextLoads() {
	}

}
